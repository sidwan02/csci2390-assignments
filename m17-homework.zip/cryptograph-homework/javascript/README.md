# libsodium with nodejs

## Step 1: installation

Run `npm install`

## Step 2: implementation

Write you implementation in `index.js`. You can run your implementation using `node index.js`.

## Step 3: answer the questions on our course website!
